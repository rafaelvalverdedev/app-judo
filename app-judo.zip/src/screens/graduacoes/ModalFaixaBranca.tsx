import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Modal,
  SafeAreaView,
  Image,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';

export default function FaixaBranca() {
  return (
    <>
      <View style={styles.ContainerFaixaBranca }>
        <Text>asdasa</Text>
        <Text>asdas</Text>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  ContainerFaixaBranca: {
    flex: 1,
    backgroundColor: '#f6f6f6',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
