// src/components/index.ts
export { default as FaixaCard } from './FaixaCard';
export { default as FaixaModal } from './FaixaModal';