// src/components/index.ts
export { default as FaixaVisualizacao } from './FaixaVisualizacao';
export { default as FaixaCard } from './FaixaCard';
export { default as FaixaModal } from './FaixaModal';