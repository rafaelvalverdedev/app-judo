// src/components/FaixaModal.tsx
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, Modal, StyleSheet, StatusBar } from 'react-native';

import { imagensFaixas } from '../../components/imagensFaixas';

import FaixaBranca from './ModalFaixaBranca'; // Adjust path as needed
import FaixaCinza from './ModalFaixaCinza'; // Adjust path as needed
import { Texto } from '../../components/Texto';

// Tipos (assuming Faixa is defined elsewhere or imported)
interface Faixa {
  cor: string;
  ponteira: string;
  nome: string;
  requisitos: string[];
  videoUrl: string;
  imagem?: string;
  descricao: string;
}

interface FaixaModalProps {
  visible: boolean;
  faixa: Faixa | null;
  onClose: () => void;
}

const faixaComponents: { [nome: string]: React.ComponentType } = {
  'Faixa Branca': FaixaBranca,
  'Faixa Cinza': FaixaCinza,
  // Add other specific belt components here
  // 'Amarela': FaixaAmarela,
};

const FaixaModal = ({ visible, faixa, onClose }: FaixaModalProps) => {
  if (!faixa) return null;

  const ConteudoComponente = faixaComponents[faixa.nome] || null;
  const imagem = imagensFaixas[faixa.nome];

  return (
    <Modal
      visible={visible}
      animationType="fade"
      transparent
    >
      <StatusBar backgroundColor="rgba(0, 0, 0, 0.5)" barStyle="light-content" />

      <View style={styles.modalOverlay}>

        <View style={styles.modalContainer}>

          <Image source={imagem} style={styles.imagemFaixa} resizeMode='contain' />
          <Text style={styles.modalTitulo}>{faixa.nome}</Text>
          
          <ScrollView contentContainerStyle={styles.modalScrollContent}>
            {/* Renderiza componente específico da faixa */}
            {ConteudoComponente ? (<ConteudoComponente />) : (
              <Texto>
                Conteúdo indisponível para esta faixa.
              </Texto>
            )}
          </ScrollView>

          <TouchableOpacity onPress={onClose} >
            <Texto style={styles.botaoFecharTexto}>Fechar</Texto>
          </TouchableOpacity>

        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  imagemFaixa: {
    width: 60,
    height: 60,
    margin: -15,
  },

  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  modalContainer: {
    backgroundColor: '#ffffff',
    width: '90%',
    maxHeight: '90%',
    borderRadius: 16,
    padding: 16,
    elevation: 10,
    shadowColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },

  modalScrollContent: {
    width: '100%',
    paddingBottom: 10,
  },

  modalTitulo: {
    textAlign: 'center',
    marginBottom: 6,
    fontSize: 21,
    fontWeight: 'bold',
    color: '#555555',
  },

  botaoFechar: {
    marginTop: 24,
    alignSelf: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#007AFF',
    borderRadius: 8,
    elevation: 2,
  },

  botaoFecharTexto: {
    color: 'red',
    fontWeight: '900',
    fontSize: 14,
  },

});

export default FaixaModal;