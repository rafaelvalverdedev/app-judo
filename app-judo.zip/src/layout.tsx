// Constantes
export const COLORS = {
  primary: '#A81412',
  background: '#d6dde0',
  cardBackground: '#f6f6f6',
  cardSecondary: '#eeeded',
  black: '#333',
  white: '#fff',
  text: '#333',
  overlay: 'rgba(0,0,0,0.6)',
};